#include "SD_Si_det.hh"
#include<G4OpticalPhoton.hh>

SD_Si_det :: SD_Si_det (G4String SDname) : G4VSensitiveDetector(SDname) 
{
// collectionName.insert("SDhitSi_detCollection");
 
 G4String filename[10];
 char str[3];
 G4int i;
 for (i=0;i<10;i++)
 {
  filename[i] ="hit_Si_det_";
  sprintf(str,"%d",i+1);
  filename[i]+=str;
  filename[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_det[i].open(filename[i],std::fstream::out);
 }

 for (i=0; i<10; i++)
 {
  SumE[i]=0.; CopyNum0[i]=0.; CopyNum1[i]=0.; CopyNum2[i]=0.;
  world[i]=G4ThreeVector(0.,0.,0.); local[i]=G4ThreeVector(0.,0.,0.);
 }
}

SD_Si_det :: ~SD_Si_det()
{
 for (G4int i=0; i<10; i++) 
 {hit_SD_Si_det[i].close();}
}

extern G4int eventID;

void SD_Si_det :: EndOfEvent(G4HCofThisEvent*)
{
 for (G4int k=0; k<10; k++)
 {
  if (this->GetCopyNum0(k)>0)
  {
   hit_SD_Si_det[k] << " copy=" << std::setw(10) << this->GetCopyNum0(k);
   hit_SD_Si_det[k] << " energy in layer=" << std::setw(10) << SumE[k] << " coordinate local=" << std::setw(10) << this->GetLocal(k) 
                    << " coordinate world=" << std::setw(10) << this->GetWorld(k) << G4endl;
   for (G4int j=0; j<10; j++)
   {
    if (this->GetCopyNum1(j)>0)
    {
     hit_SD_Si_det[k] << " parent copy=" << std::setw(10) << this->GetCopyNum1(j);
    }
   }
   for (G4int i=0; i<10; i++)
   {
    if (this->GetCopyNum2(i)>0)
    {
     hit_SD_Si_det[k] << " grand copy=" << std::setw(10) << this->GetCopyNum2(i);
    }
   }
  }
 }
 for (G4int i=0; i<10; i++)
 {SumE[i]=0.;}
}

G4bool SD_Si_det :: ProcessHits(G4Step* step, G4TouchableHistory*)
{
 if (step->GetPostStepPoint()->GetMaterial()==G4NistManager::Instance()->FindOrBuildMaterial("G4_Si"))
 {
  G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
  G4int copyNo0  = touchable->GetReplicaNumber(0); 
  G4int copyNo1  = touchable->GetReplicaNumber(1); G4cout<<"No1="<<copyNo1<<G4endl;
  G4int copyNo2  = touchable->GetReplicaNumber(2);
  this->SetCopyNum0(copyNo0);
  this->SetCopyNum1(copyNo1);
  this->SetCopyNum2(copyNo2);

//  G4String pname = step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName();
  G4double edep  = 0.;
//  G4double time_ = step->GetPreStepPoint()->GetGlobalTime();
//  edep           = step->GetTrack()->GetDynamicParticle()->GetTotalEnergy()*1e6;
  edep           = step->GetTotalEnergyDeposit();
  this->AddSumE(edep,copyNo0);
  
  G4ThreeVector world_pos =step->GetPreStepPoint()->GetPosition();
  this->SetWorld(world_pos,copyNo0);
  G4ThreeVector local_pos =touchable->GetHistory()->GetTopTransform().TransformPoint(world_pos);
  this->SetLocal(local_pos,copyNo0);
 }
 return true;
}

