#include "hist.hpp"

Hist::Hist(double l, double h, int n){
    lb=l;
    hb=h;
    nc=n;
    step=(hb-lb)/nc;
    hh = (int*)calloc(nc, sizeof(int));
}

void Hist::fill(double ksi){
    if(ksi >= lb && ksi < hb){
        int k = (int)((ksi-lb)/step);
        hh[k]++;
    }
}

int Hist::get_bin_value(int n){
    if(n>=0 && n<nc ) return hh[n];
    else return -1;
}

double Hist::get_bin(int n){
    if(n>=0 && n<nc ) return (n+0.5)*step + lb;
    else return -1;
}

#include <iostream>
#include <iomanip>

using namespace std;

void stars(int n){
    for(int i = 0; i < n; ++i)
        cout << '*';
}

void Hist::draw(int width){
    int max = 0;
    for(int i = 0; i < nc; ++i) {
        if (hh[i] > max)
            max = hh[i];
    }
    for(int i = 0; i < nc; ++i) {
        cout << setw(6) << setprecision(3) << i*step + lb;
        cout << " - ";
        cout << setw(6) << setprecision(3) << (i+1)*step + lb;
        cout << ": |";
        stars(hh[i]*width/max);
        cout << endl;
    }
}
// ***** end of class Hist *****

